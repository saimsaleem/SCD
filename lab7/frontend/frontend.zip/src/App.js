import './App.css';
import { useState , useEffect} from "react";
import axios from "axios";
export default App;

function App() {

  const [listofUsers,setListofUsers]= useState([]);
  const [name,setName]= useState("")
 
   const createUser = () => {
    alert(name);
//     fetch('http://localhost:3001/add', {
//  name
// });
    axios.post('http://localhost:3001/add', {
      name,
    })
    .then(function (response) {
      return response;
    })
    .catch(function (error) {
      return error;
    });
  //   alert("Hello");
  //   axios.post('http://localhost:3001/add', {
  //      name:'saimsssss',
  //    }).then((response)=> {
  //     alert("User Created");
     
  //   });
   };

 

  useEffect( () => {

    axios.get("http://localhost:3001").then((response) => {
     setListofUsers(response.data);
    });
   }, []);
  return (
    <div className="App">
      <h1>Welcome</h1>
      <div className="usersDisplay">
      {listofUsers.map((users) => {
        return (
          <div>
            <h1>User</h1>
            <h1>Name : {users.name}</h1>           
           
            </div>
        )
      })}
       

      </div>
     <div>
     
      <h3>Write your data in the text box</h3>
      <input type="text" placeholder="Name" onChange={(event) => {
        setName(event.target.value);
      }}></input>
      <button onClick={createUser}>Create User</button>
     </div>

    </div>
  );
}